export interface Bug {
    id: number,
    name: string,
    isClosed: boolean,
    createdAt: Date
}